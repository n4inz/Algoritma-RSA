<?php

class convert{

	public function encrypt($chiper_text,$public_key,$nilai_n){
		$total2 = '';
		foreach(str_split($chiper_text) as $value ) {

	 	$data3 = perulangan::jumlah($value);

		$hasil = bcpowmod($data3, $public_key, $nilai_n);

		// $hasil .=".";
		$total2 .=  $hasil;
		$total2 .= ".";
	 	}
			return $total2;

		}

		public function decrypt($chiper_text,$private_key,$nilai_n)	{

			$total2 = '';
			$teks=explode(".",$chiper_text);
		  foreach($teks as $value ) {
			$hasil = chr(bcpowmod($value,$private_key,$nilai_n));

			$total2 .= $hasil;
				}
				return $total2;
			}



			public function gen($nilai_p,$nilai_q){
				if($nilai_p AND $nilai_q < 2){
					$tampil = "nilai harus diatas atau sama dengan 100";
					return $tampil;
				}else{
					$rand1=rand($nilai_p,10000);
					$rand2=rand($nilai_q,10000);


					$p = gmp_nextprime($rand1);
					$q = gmp_nextprime($rand2);


					$n=gmp_mul($p,$q);

					$nilai_tot=gmp_mul(gmp_sub($p,1),gmp_sub($q,1));

					$e = perulangan::nilai_e($nilai_tot);

					$d = perulangan::nilai_d($nilai_tot,$e);


					$kunci = "Public key = ($e,$n) \nPrivate key = ($d,$n)";


					$_SESSION['n'] = $n;
					$_SESSION['e'] = $e;
					$_SESSION['d'] = $d;

				//	echo $_SESSION['e'];

				 //echo "public key = ($e,$n) \n";
				// echo "Private key ($d,$n)";
				return $kunci;

				}

			}


}
