<?php

class perulangan{


public function nilai_e($nilai_e){

  for($e=2;$e<100;$e++){
      $gcd = gmp_gcd($e, $nilai_e);
      if(gmp_strval($gcd)=='1')
          break;

  }

  return $e;

}

public function nilai_d($nilai_d,$nilai_e){

  $i=1;
  do{
      $kali = gmp_mul($nilai_d,$i);
      $tambah = gmp_add($kali,1);
      $r = gmp_div_qr($tambah, $nilai_e);

      $i++;
      if($i==10000)
        break;
  }while(gmp_strval($r[1])!='0');

  return $r[0];

}


public function jumlah($data2){
//$data3 = strtoupper($data2);
$ord = ord($data2);
return $ord;
}

}

 ?>
