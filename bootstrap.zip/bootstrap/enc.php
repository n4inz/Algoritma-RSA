<?php
session_start();
require_once 'autoload/init.php';

$chiper_text = $_POST['chiper_text'];
$public_key = $_POST['public_key'];
$nilai_n = $_POST['nilai_n'];

$keluar = $convert->encrypt($chiper_text,$public_key,$nilai_n);

$_SESSION["enc"] = $keluar;
echo $keluar;
