<?php
require_once 'autoload/init.php';

$chiper_text = $_POST['chiper_text'];
$private_key = $_POST['private_key'];
$nilai_n = $_POST['nilai_n'];

$keluar = $convert->decrypt($chiper_text,$private_key,$nilai_n);
echo $keluar;
