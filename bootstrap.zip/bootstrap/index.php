<?php
error_reporting(0);
session_start();

//echo	$_SESSION['n'];

require_once 'autoload/init.php';



if( isset($_POST['submit'])){
  $nilai_p = $_POST['nilai_p'];
  $nilai_q = $_POST['nilai_q'];

  $keluar = $convert->gen($nilai_p,$nilai_q);

}


 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="Assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="Assets/css/costum.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js">
</script>

<script>
   $(document).ready(function() {
     $("#tombol").submit(function(event){
       event.preventDefault();
       var url = $("#input").attr('action');
       console.log(url)
     });
   });

   $(document).ready(function (e) {
     $("#Form_enc").on('submit',(function(e) {
       e.preventDefault();
       $.ajax({
         url: "enc.php",
         type: "POST",
         data:  new FormData(this),
         contentType: false,
             cache: false,
         processData:false,
         success: function(response)
           {
             //$('.msg').show();
             if(response == ""){
               alert(response);
             }else{
               var msg = response;

               $('#hasil_enc').html(msg);
             }
           },
           error: function()
           {
           }
        });
     }));
   });

   $(document).ready(function (e) {
     $("#Form_dec").on('submit',(function(e) {
       e.preventDefault();
       $.ajax({
         url: "dec.php",
         type: "POST",
         data:  new FormData(this),
         contentType: false,
             cache: false,
         processData:false,
         success: function(response)
           {
             //$('.msg').show();
             if(response == ""){
               alert(response);
             }else{
               var msg = response;

               $('#hasil_dec').html(msg);
             }
           },
           error: function()
           {
           }
        });
     }));
   });

   $(document).ready(function (e) {
     $("#gen").on('submit',(function(e) {
       e.preventDefault();
       $.ajax({
         url: "gen.php",
         type: "POST",
         data:  new FormData(this),
         contentType: false,
             cache: false,
         processData:false,
         success: function(response)
           {
             //$('.msg').show();
             if(response == ""){
               alert(response);
             }else{
               var msg = response;
               //alert('berhasil');

               $('#hasil_gen').html(msg);
             }
           },
           error: function()
           {
           }
        });
     }));
   });
</script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>


    <header><h1>Engkripsi Text Mengunakan Algoritma RSA</h1></header>
    <div class="container">
  <div id="content">
    <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
      <li class="active"><a href="#tab-1" data-toggle="tab">Generate</a></li>
      <li><a href="#tab-2" data-toggle="tab">Engkripsi</a></li>
      <li><a href="#tab-3" data-toggle="tab">Deskripsi</a></li>
    </ul>
    <!-- AWAL KONTENT -->
    <div id="my-tab-content" class="tab-content">

      <!-- AWAL TAB 1 -->
      <div class="tab-pane active" id="tab-1">
        <div class="col-sm-12" id="kotak">
          <form id="gens" method="post" action="" >
          <div class="col-sm-6">
            <div class="col-sm-10">
              <input id="input1" name="nilai_p" type="text" class="form-control" placeholder="Masukkan Nilai P">
              <input id="input2" name="nilai_q" type="text" class="form-control" placeholder="Masukkan Nialai Q">

              <input type="submit" class="submit"  name="submit"  value="Generate" />
            </form>
            </div>
          </div>

          <div class="col-sm-6">
            <div class="col-sm-4">
              <textarea id="hasil_gen" name="chiper_text" placeholder="Hasil"><?= $keluar;?></textarea>
            </div>
          </div>

        </div>
      </div>
      <!-- AKHIR TAB 1 -->

      <!-- AWAL TAB 2 -->
      <div class="tab-pane" id="tab-2">
          <div class="col-sm-12" id="kotak">
            <form id="Form_enc" method="post" action="" >
            <div class="col-sm-4">
              <label>Pesan :</label>
              <textarea name="chiper_text" placeholder="Masukan Pesan Anda"></textarea>
            </div>
            <div class="col-sm-4">
              <div class="col-sm">
                <input id="input1" name="public_key" type="text" class="form-control" placeholder="Public Key" value="<?=$_SESSION['e']?>">
                <input id="input2" name="nilai_n" type="text" class="form-control" placeholder="N(P * Q)" value="<?php echo  $_SESSION['n']; ?>">
                <input type="submit" class="submit"  name="submit"  value="ENCRYPT" />
              </div>
            </div>
            </form>
            <div class="col-sm-4">
              <label>Hasil :</label>
              <textarea id="hasil_enc" placeholder="Hasil"></textarea>
            </div>
            </form>
          </div>
      </div>
      <!-- AKHIR TAB 2 -->

      <!-- AWAL TAB 3 -->
      <div class="tab-pane" id="tab-3">
        <div class="col-sm-12" id="kotak">
          <form id="Form_dec" method="post" action="" >
          <div class="col-sm-4">
            <label>Pesan :</label>
            <textarea name="chiper_text" placeholder="Masukan Pesan Anda"></textarea>
          </div>
          <div class="col-sm-4">
            <div class="col-sm">
              <input id="input1" type="text" name="private_key" class="form-control" placeholder="Private Key" value="<?=$_SESSION['d']?>">
              <input id="input2" type="text" name="nilai_n"class="form-control" placeholder="N(P * Q)" value="<?php echo  $_SESSION['n']; ?>">
              <input type="submit" class="submit"  name="submit"  value="DECRYPT" />
            </div>
          </div>
          </form>
          <div class="col-sm-4">
            <label>Hasil :</label>
            <textarea id="hasil_dec" placeholder="Masukan Pesan Anda"></textarea>
          </div>

        </div>
      </div>
      <!-- AKHIR TAB 3 -->
    </div>
    <!-- AKHIR KONTENT -->

  </div>
</div>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="Assets/js/bootstrap.min.js"></script>
  </body>
</html>
